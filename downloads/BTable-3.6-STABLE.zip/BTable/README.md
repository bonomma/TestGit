BTable
======

A drill-anywhere component for the Pentaho Community Dashboard Designer (CDE).
 
Video tutorial and more on [www.biztech.it/btable](http://www.biztech.it/btable).
 
BTable is released under the [Mozilla Public Licence (MPLv2)](http://www.mozilla.org/MPL/2.0/). 
 
This plugin has been made using [Sparkl](https://github.com/webdetails/sparkl).
